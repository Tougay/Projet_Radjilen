import tensorflow as tf
import tensorflow_hub as hub
import mysql.connector

def calculer_similarite_use(reponse_candidat, reponse_attendue):
    try:
        # Chargement du modèle Universal Sentence Encoder
        embed = hub.load("https://tfhub.dev/google/universal-sentence-encoder/4")

        # Encodage des phrases en vecteurs
        vecteur_candidat = embed([reponse_candidat])[0]
        vecteur_attendu = embed([reponse_attendue])[0]

        # Calcul de la similarité entre les vecteurs (produit scalaire)
        similarite = tf.tensordot(vecteur_candidat, vecteur_attendu, axes=1)
        pourcentage_similarite = similarite * 100

        return pourcentage_similarite.numpy().item()

    except Exception as e:
        print("Erreur lors du calcul de similarité :", e)
        return None

# Connexion à la base de données MySQL
connection = mysql.connector.connect(host="localhost", user="root", password="", database="cee_db")

if connection.is_connected():
    cursor = connection.cursor()

    # Exécution d'une requête pour récupérer l'ID de l'examen (par exemple, le dernier enregistrement)
    cursor.execute("SELECT ex_id FROM exam_tbl ORDER BY ex_id DESC LIMIT 1")
    id_examen = cursor.fetchone()[0]  # Récupérer l'ID de l'examen

    # Exécution d'une requête pour récupérer les réponses du candidat et les réponses attendues
    query = "SELECT reponse_candidat, reponse_attendue FROM exam_tbl WHERE ex_id = %s"
    cursor.execute(query, (id_examen,))
    result = cursor.fetchone()

    if result:
        reponse_candidat = result[1]
        reponse_attendue = result[0]

        # Calcul de similarité
        resultat_similarite = calculer_similarite_use(reponse_candidat, reponse_attendue)

        # Sauvegarde du résultat de similarité dans la base de données
        update_query = "UPDATE exam_tbl SET similarite = %s WHERE ex_id = %s"
        cursor.execute(update_query, (resultat_similarite, id_examen))
        connection.commit()

        print(resultat_similarite)

    # Fermeture du curseur et de la connexion à la base de données
    cursor.close()
    connection.close()
else:
    print("Connexion à la base de données échouée")

#import tensorflow as tf
#import tensorflow_hub as hub
#
#def calculer_similarite_use(reponse_candidat, reponse_attendue):
#    try:
#        # Chargement du modèle Universal Sentence Encoder
#        embed = hub.load("https://tfhub.dev/google/universal-sentence-encoder/4")
#
#        # Encodage des phrases en vecteurs
#        vecteur_candidat = embed([reponse_candidat])[0]
#        vecteur_attendu = embed([reponse_attendue])[0]
#
#        # Calcul de la similarité entre les vecteurs (produit scalaire)
#        similarite = tf.tensordot(vecteur_candidat, vecteur_attendu, axes=1)
#        pourcentage_similarite = similarite * 100
#
#        return pourcentage_similarite.numpy().item()
#
#    except Exception as e:
#        print("Erreur lors du calcul de similarité :", e)
#        return None
#
## Exemple d'utilisation avec les variables reponse_candidat et reponse_attendue
#reponse_candidat = "ce sont des matieres"
#reponse_attendue = "ce sont des matieres"
#
#resultat_similarite = calculer_similarite_use(reponse_candidat, reponse_attendue)
#print(resultat_similarite)
#