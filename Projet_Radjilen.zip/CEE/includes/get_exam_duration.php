<?php
// Connexion à la base de données
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cee_db";

// Création de la connexion
$conn = new mysqli($servername, $username, $password, $dbname);

// Vérification de la connexion
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

if (isset($_GET['exam_id'])) {
    $examId = $_GET['exam_id'];

    // Requête pour obtenir la durée de l'examen à partir de la table exam_tbl
    $sql = "SELECT ex_time_limit FROM exam_tbl WHERE ex_id = $examId";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo $row['ex_time_limit']; // Envoyer la durée de l'examen en secondes à la requête AJAX
    } else {
        echo "0"; // Si aucun enregistrement n'est trouvé pour cet ID d'examen
    }
} else {
    echo "0"; // Si l'ID de l'examen n'est pas fourni via la requête GET
}

$conn->close();
?>
