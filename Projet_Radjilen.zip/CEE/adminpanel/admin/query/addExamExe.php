<?php
include("../../../conn.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    extract($_POST);

    // Vérifiez si tous les champs nécessaires sont définis
    if (isset($courseSelected, $timeLimit, $examTitle, $examDesc, $reponse_attendue)) {
        // Utilisez des requêtes préparées pour éviter les injections SQL et échapper les valeurs
        $insExam = $conn->prepare("INSERT INTO exam_tbl (cou_id, titre, ex_time_limit, contenu, reponse_attendue) VALUES (?, ?, ?, ?, ?)");

        // Exécution de la requête préparée avec les valeurs échappées
        if ($insExam->execute([$courseSelected, $examTitle, $timeLimit, $examDesc, $reponse_attendue])) {
            $res = array("res" => "success", "examTitle" => $examTitle);
        } else {
            $res = array("res" => "failed", "examTitle" => $examTitle);
        }
    } else {
        $res = array("res" => "missingFields");
    }
} else {
    $res = array("res" => "invalidMethod");
}

echo json_encode($res);

?>
